#ifndef CONSTANTS_H
#define CONSTANTS_H

const float PI = 3.141592653589793f;

#endif
