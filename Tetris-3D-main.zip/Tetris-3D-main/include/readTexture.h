#pragma once

#include <GL/glew.h>

GLuint readTexture(const char* filename);